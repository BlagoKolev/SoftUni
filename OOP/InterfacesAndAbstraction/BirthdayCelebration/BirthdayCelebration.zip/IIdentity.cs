﻿namespace BirthdayCelebrations
{
    public interface IIdentity
    {
        string Name { get; }
        string Birthdate { get; }
    }
}
