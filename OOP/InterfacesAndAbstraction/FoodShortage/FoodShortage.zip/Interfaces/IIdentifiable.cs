﻿namespace FoodShortage.Intefaces
{
   public interface IIdentifiable
    {
        string Id { get; }
    }
}
