﻿namespace FoodShortage.Intefaces
{
   public interface IAge
    {
        int Age { get; }
    }
}
