﻿namespace FoodShortage.Intefaces
{
   public interface IBirthable
    {
        string Birthdate { get; }
    }
}
