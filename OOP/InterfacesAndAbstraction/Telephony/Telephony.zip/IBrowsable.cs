﻿using System;


namespace Telephony
{
    interface IBrowsable
    {
        string Browse(string text);
    }
}
