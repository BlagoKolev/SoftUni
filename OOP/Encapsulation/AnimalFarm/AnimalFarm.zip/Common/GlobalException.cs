﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalFarm.Common
{
    public class GlobalException
    {
        public static string InvalidAgeException = "Age should be between {0} and {1}.";
        public static string InvalidNameException = "Name cannot be empty.";
    }
}
