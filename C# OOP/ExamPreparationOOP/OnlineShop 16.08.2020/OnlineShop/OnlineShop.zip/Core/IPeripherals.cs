﻿namespace OnlineShop.Core
{
    internal interface IPeripherals
    {
    }
}