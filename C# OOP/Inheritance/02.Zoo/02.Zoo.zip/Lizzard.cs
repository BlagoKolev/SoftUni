﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zoo
{
    public class Lizzard : Reptile
    {
        public Lizzard(string name)
            : base(name)
        {

        }
    }
}
