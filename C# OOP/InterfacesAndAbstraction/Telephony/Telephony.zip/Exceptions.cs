﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public static class Exceptions
    {
        public static string InvalidPhoneException = "Invalid number!";
        public static string InvalidURLException = "Invalid URL!";
    }
}
