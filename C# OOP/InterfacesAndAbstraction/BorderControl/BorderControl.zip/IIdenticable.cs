﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
   public interface IIdenticable
    {
        public string ID { get; }
    }
}
